<?php

/**
 * 角色组信息
 * @author auto create
 */
class OpenRoleGroup
{
	
	/** 
	 * 角色组名
	 **/
	public $group_name;
	
	/** 
	 * 角色列表信息
	 **/
	public $roles;	
}
?>