<?php

/**
 * 发票列表
 * @author auto create
 */
class OpenInvoiceDo
{
	
	/** 
	 * 商旅发票id
	 **/
	public $id;
	
	/** 
	 * 发票抬头
	 **/
	public $title;	
}
?>