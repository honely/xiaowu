<?php

/**
 * result
 * @author auto create
 */
class OrgShortcutVO
{
	
	/** 
	 * 类型，1表示工作台微应用
	 **/
	public $type;
	
	/** 
	 * 微应用的agentId
	 **/
	public $value;	
}
?>