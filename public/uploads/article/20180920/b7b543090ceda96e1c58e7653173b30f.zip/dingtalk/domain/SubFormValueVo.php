<?php

/**
 * details
 * @author auto create
 */
class SubFormValueVo
{
	
	/** 
	 * 明细表单别名
	 **/
	public $detail_form_biz_alias;
	
	/** 
	 * 明细扩展值
	 **/
	public $detail_form_ext_value;
	
	/** 
	 * 明细表单控件id
	 **/
	public $detail_form_id;
	
	/** 
	 * 明细表单名称
	 **/
	public $detail_form_name;
	
	/** 
	 * 明细表单值
	 **/
	public $detail_form_value;	
}
?>