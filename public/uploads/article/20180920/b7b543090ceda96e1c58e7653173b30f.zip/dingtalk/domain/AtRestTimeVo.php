<?php

/**
 * restTimeVOList
 * @author auto create
 */
class AtRestTimeVo
{
	
	/** 
	 * 休息开始时间
	 **/
	public $rest_begin_time;
	
	/** 
	 * 休息结束时间
	 **/
	public $rest_end_time;	
}
?>