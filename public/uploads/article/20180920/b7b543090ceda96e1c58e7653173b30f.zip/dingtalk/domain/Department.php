<?php

/**
 * department
 * @author auto create
 */
class Department
{
	
	/** 
	 * autoAddUser
	 **/
	public $auto_add_user;
	
	/** 
	 * createDeptGroup
	 **/
	public $create_dept_group;
	
	/** 
	 * id
	 **/
	public $id;
	
	/** 
	 * name
	 **/
	public $name;
	
	/** 
	 * parentid
	 **/
	public $parentid;
	
	/** 
	 * sourceIdentifier
	 **/
	public $source_identifier;	
}
?>