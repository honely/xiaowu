<?php

/**
 * 结果对象
 * @author auto create
 */
class OpenApiNewApplyRs
{
	
	/** 
	 * 商旅申请单id
	 **/
	public $apply_id;
	
	/** 
	 * 外部申请单id
	 **/
	public $thirdpart_apply_id;	
}
?>