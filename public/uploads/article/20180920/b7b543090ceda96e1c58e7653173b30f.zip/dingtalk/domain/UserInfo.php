<?php

/**
 * user_info
 * @author auto create
 */
class UserInfo
{
	
	/** 
	 * avatar
	 **/
	public $avatar;
	
	/** 
	 * email
	 **/
	public $email;
	
	/** 
	 * name
	 **/
	public $name;
	
	/** 
	 * 员工在企业内的UserID
	 **/
	public $userid;	
}
?>