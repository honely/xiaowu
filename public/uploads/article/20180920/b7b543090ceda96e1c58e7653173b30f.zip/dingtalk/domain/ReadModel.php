<?php

/**
 * 已读的接收者及时间列表 receiverId：用户id readTime：阅读时间，Long
 * @author auto create
 */
class ReadModel
{
	
	/** 
	 * readTime
	 **/
	public $read_time;
	
	/** 
	 * receiverId
	 **/
	public $receiver_id;	
}
?>