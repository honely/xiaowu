<?php

/**
 * 此消息类型为固定feedCard
 * @author auto create
 */
class Feedcard
{
	
	/** 
	 * links
	 **/
	public $links;	
}
?>