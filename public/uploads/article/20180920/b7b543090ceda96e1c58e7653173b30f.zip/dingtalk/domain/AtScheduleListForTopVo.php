<?php

/**
 * result
 * @author auto create
 */
class AtScheduleListForTopVo
{
	
	/** 
	 * 分页用，表示是否还有下一页
	 **/
	public $has_more;
	
	/** 
	 * 排班列表
	 **/
	public $schedules;	
}
?>