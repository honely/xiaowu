<?php

/**
 * 系统自动生成
 * @author auto create
 */
class GetRelationReq
{
	
	/** 
	 * 接收者钉钉的openid
	 **/
	public $dst_im_openids;
	
	/** 
	 * 发送者钉钉的openid
	 **/
	public $src_im_openid;	
}
?>