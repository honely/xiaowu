<?php

/**
 * formValueVOS
 * @author auto create
 */
class FormValueVo
{
	
	/** 
	 * 表单别名
	 **/
	public $biz_alias;
	
	/** 
	 * 明细列表
	 **/
	public $details;
	
	/** 
	 * 扩展值
	 **/
	public $ext_value;
	
	/** 
	 * 表单控件id
	 **/
	public $form_id;
	
	/** 
	 * 表单名称
	 **/
	public $name;
	
	/** 
	 * 表单值
	 **/
	public $value;	
}
?>