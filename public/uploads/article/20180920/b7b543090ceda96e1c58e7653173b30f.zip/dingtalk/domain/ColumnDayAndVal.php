<?php

/**
 * 列值数据
 * @author auto create
 */
class ColumnDayAndVal
{
	
	/** 
	 * 时间
	 **/
	public $date;
	
	/** 
	 * 列值
	 **/
	public $value;	
}
?>