<?php

/**
 * result
 * @author auto create
 */
class AddProfileResp
{
	
	/** 
	 * imOpenId
	 **/
	public $im_openid;	
}
?>