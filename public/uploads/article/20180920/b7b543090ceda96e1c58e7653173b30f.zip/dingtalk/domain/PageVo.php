<?php

/**
 * result
 * @author auto create
 */
class PageVo
{
	
	/** 
	 * hasMore
	 **/
	public $has_more;
	
	/** 
	 * list
	 **/
	public $list;	
}
?>