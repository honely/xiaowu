<?php

/**
 * file
 * @author auto create
 */
class File
{
	
	/** 
	 * media_id
	 **/
	public $media_id;	
}
?>