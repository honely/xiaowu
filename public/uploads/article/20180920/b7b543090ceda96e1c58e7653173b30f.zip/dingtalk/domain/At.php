<?php

/**
 * 被@人的手机号
 * @author auto create
 */
class At
{
	
	/** 
	 * 被@人的手机号
	 **/
	public $at_mobiles;
	
	/** 
	 * @所有人时:true,否则为:false
	 **/
	public $is_at_all;	
}
?>