<?php

/**
 * result
 * @author auto create
 */
class AtGroupListForTopVo
{
	
	/** 
	 * 考勤组列表
	 **/
	public $groups;
	
	/** 
	 * 分页用，表示是否还有下一页
	 **/
	public $has_more;	
}
?>