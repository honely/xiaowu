<?php

/**
 * result
 * @author auto create
 */
class CorpCalendarCreateResult
{
	
	/** 
	 * dingtalkCalendarId
	 **/
	public $dingtalk_calendar_id;
	
	/** 
	 * invalidUser
	 **/
	public $invalid_userids;	
}
?>