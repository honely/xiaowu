<?php

/**
 * agent
 * @author auto create
 */
class Agent
{
	
	/** 
	 * admin_list
	 **/
	public $admin_list;
	
	/** 
	 * agent_name
	 **/
	public $agent_name;
	
	/** 
	 * agentid
	 **/
	public $agentid;
	
	/** 
	 * appid
	 **/
	public $appid;
	
	/** 
	 * logo_url
	 **/
	public $logo_url;	
}
?>