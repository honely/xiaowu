<?php

/**
 * result
 * @author auto create
 */
class OpenRole
{
	
	/** 
	 * 角色组id
	 **/
	public $group_id;
	
	/** 
	 * 角色名称
	 **/
	public $name;	
}
?>