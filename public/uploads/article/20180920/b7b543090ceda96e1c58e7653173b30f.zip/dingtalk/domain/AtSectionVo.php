<?php

/**
 * 班次中上下班列表
 * @author auto create
 */
class AtSectionVo
{
	
	/** 
	 * 班次中上下班详情列表
	 **/
	public $times;	
}
?>