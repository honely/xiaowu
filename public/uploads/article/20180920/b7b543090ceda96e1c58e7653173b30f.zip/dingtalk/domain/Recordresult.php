<?php

/**
 * recordresult
 * @author auto create
 */
class Recordresult
{
	
	/** 
	 * approveId
	 **/
	public $approve_id;
	
	/** 
	 * baseCheckTime
	 **/
	public $base_check_time;
	
	/** 
	 * checkType
	 **/
	public $check_type;
	
	/** 
	 * groupId
	 **/
	public $group_id;
	
	/** 
	 * id
	 **/
	public $id;
	
	/** 
	 * locationResult
	 **/
	public $location_result;
	
	/** 
	 * planId
	 **/
	public $plan_id;
	
	/** 
	 * procInstId
	 **/
	public $proc_inst_id;
	
	/** 
	 * recordId
	 **/
	public $record_id;
	
	/** 
	 * sourceType
	 **/
	public $source_type;
	
	/** 
	 * timeResult
	 **/
	public $time_result;
	
	/** 
	 * userCheckTime
	 **/
	public $user_check_time;
	
	/** 
	 * userId
	 **/
	public $user_id;
	
	/** 
	 * workDate
	 **/
	public $work_date;	
}
?>