<?php

/**
 * rich
 * @author auto create
 */
class Rich
{
	
	/** 
	 * num
	 **/
	public $num;
	
	/** 
	 * unit
	 **/
	public $unit;	
}
?>