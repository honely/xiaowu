<?php

/**
 * result
 * @author auto create
 */
class TaskSendResult
{
	
	/** 
	 * dingId
	 **/
	public $ding_id;	
}
?>