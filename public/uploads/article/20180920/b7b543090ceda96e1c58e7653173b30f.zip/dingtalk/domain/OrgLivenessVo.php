<?php

/**
 * result
 * @author auto create
 */
class OrgLivenessVo
{
	
	/** 
	 * 活跃度，L1：不活跃，L2：低活跃，L3：中活跃，L4：高活跃，L5：超活跃
	 **/
	public $liveness;	
}
?>