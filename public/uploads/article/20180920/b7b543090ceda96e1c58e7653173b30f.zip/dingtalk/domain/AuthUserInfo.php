<?php

/**
 * auth_user_info
 * @author auto create
 */
class AuthUserInfo
{
	
	/** 
	 * userId
	 **/
	public $user_id;	
}
?>