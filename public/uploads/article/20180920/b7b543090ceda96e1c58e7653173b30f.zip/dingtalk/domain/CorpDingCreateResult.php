<?php

/**
 * 返回结果
 * @author auto create
 */
class CorpDingCreateResult
{
	
	/** 
	 * invalidUser
	 **/
	public $invalid_users;
	
	/** 
	 * openDingId
	 **/
	public $open_ding_id;	
}
?>