<?php

/**
 * 语音消息
 * @author auto create
 */
class Voice
{
	
	/** 
	 * duration
	 **/
	public $duration;
	
	/** 
	 * media_id
	 **/
	public $media_id;	
}
?>