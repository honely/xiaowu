<?php

/**
 * userlist
 * @author auto create
 */
class Userlist
{
	
	/** 
	 * name
	 **/
	public $name;
	
	/** 
	 * userid
	 **/
	public $userid;	
}
?>