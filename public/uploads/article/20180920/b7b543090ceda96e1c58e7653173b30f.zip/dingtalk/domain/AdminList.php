<?php

/**
 * admin_list
 * @author auto create
 */
class AdminList
{
	
	/** 
	 * sys_level
	 **/
	public $sys_level;
	
	/** 
	 * userid
	 **/
	public $userid;	
}
?>