<?php

/**
 * channelAgent
 * @author auto create
 */
class Channelagent
{
	
	/** 
	 * agent_name
	 **/
	public $agent_name;
	
	/** 
	 * agentid
	 **/
	public $agentid;
	
	/** 
	 * appid
	 **/
	public $appid;
	
	/** 
	 * logo_url
	 **/
	public $logo_url;	
}
?>