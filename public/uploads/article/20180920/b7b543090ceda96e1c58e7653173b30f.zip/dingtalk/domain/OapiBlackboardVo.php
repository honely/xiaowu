<?php

/**
 * result
 * @author auto create
 */
class OapiBlackboardVo
{
	
	/** 
	 * 创建时间
	 **/
	public $gmt_create;
	
	/** 
	 * 标题
	 **/
	public $title;
	
	/** 
	 * 跳转URL
	 **/
	public $url;	
}
?>