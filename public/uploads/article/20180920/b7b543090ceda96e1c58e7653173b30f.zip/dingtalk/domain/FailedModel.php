<?php

/**
 * 发送失败的详情 receiverId：失败的id code：失败的错误码 msg：失败的原因
 * @author auto create
 */
class FailedModel
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * msg
	 **/
	public $msg;
	
	/** 
	 * receiverId
	 **/
	public $receiver_id;	
}
?>