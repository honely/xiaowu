<?php

/**
 * result
 * @author auto create
 */
class AttColumnsForTopVo
{
	
	/** 
	 * 列信息
	 **/
	public $columns;	
}
?>