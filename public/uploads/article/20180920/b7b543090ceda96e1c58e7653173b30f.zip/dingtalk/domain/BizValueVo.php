<?php

/**
 * 表单参数列表
 * @author auto create
 */
class BizValueVo
{
	
	/** 
	 * 别名，审批表单控件唯一标识
	 **/
	public $biz_alias;
	
	/** 
	 * 扩展值
	 **/
	public $ext_value;
	
	/** 
	 * 表单值
	 **/
	public $value;	
}
?>