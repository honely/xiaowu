<?php

/**
 * result
 * @author auto create
 */
class ServiceConversationModel
{
	
	/** 
	 * ownerDingtalkId
	 **/
	public $owner_dingtalk_id;
	
	/** 
	 * ownerName
	 **/
	public $owner_name;
	
	/** 
	 * ownerNick
	 **/
	public $owner_nick;
	
	/** 
	 * ownerUserid
	 **/
	public $owner_userid;
	
	/** 
	 * title
	 **/
	public $title;
	
	/** 
	 * type
	 **/
	public $type;	
}
?>