<?php

/**
 * result
 * @author auto create
 */
class GetProfileResp
{
	
	/** 
	 * avatarMediaId
	 **/
	public $avatar_mediaid;
	
	/** 
	 * extension
	 **/
	public $extension;
	
	/** 
	 * imOpenId
	 **/
	public $im_openid;
	
	/** 
	 * nick
	 **/
	public $nick;	
}
?>