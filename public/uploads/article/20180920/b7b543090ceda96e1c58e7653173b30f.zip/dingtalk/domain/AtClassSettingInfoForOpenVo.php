<?php

/**
 * 当前排班对应的休息时间段
 * @author auto create
 */
class AtClassSettingInfoForOpenVo
{
	
	/** 
	 * restTimeVOList
	 **/
	public $rest_time_vo_list;	
}
?>