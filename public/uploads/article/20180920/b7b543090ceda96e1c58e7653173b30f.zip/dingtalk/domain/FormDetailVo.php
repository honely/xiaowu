<?php

/**
 * 明细列表
 * @author auto create
 */
class FormDetailVo
{
	
	/** 
	 * details
	 **/
	public $detail_form_values;	
}
?>