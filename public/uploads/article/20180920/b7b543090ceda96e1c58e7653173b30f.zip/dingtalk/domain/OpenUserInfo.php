<?php

/**
 * 出行人列表
 * @author auto create
 */
class OpenUserInfo
{
	
	/** 
	 * 出行人名称
	 **/
	public $user_name;
	
	/** 
	 * 出行人id
	 **/
	public $userid;	
}
?>