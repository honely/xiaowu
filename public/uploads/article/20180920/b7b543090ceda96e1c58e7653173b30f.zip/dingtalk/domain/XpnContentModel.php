<?php

/**
 * 推送信息
 * @author auto create
 */
class XpnContentModel
{
	
	/** 
	 * 推送文案
	 **/
	public $alert_content;
	
	/** 
	 * 推送参数
	 **/
	public $params;	
}
?>