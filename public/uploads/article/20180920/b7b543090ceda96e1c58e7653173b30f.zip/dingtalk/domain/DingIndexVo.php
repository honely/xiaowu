<?php

/**
 * result
 * @author auto create
 */
class DingIndexVo
{
	
	/** 
	 * 月平均钉钉指数
	 **/
	public $avarage_month_index;
	
	/** 
	 * 日钉钉指数
	 **/
	public $day_index;
	
	/** 
	 * 统计时间
	 **/
	public $stat_date;	
}
?>