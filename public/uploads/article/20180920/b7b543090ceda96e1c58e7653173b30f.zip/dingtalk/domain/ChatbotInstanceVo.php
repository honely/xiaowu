<?php

/**
 * result
 * @author auto create
 */
class ChatbotInstanceVo
{
	
	/** 
	 * 机器人实例userId
	 **/
	public $chatbot_user_id;
	
	/** 
	 * 机器人发消息时的地址
	 **/
	public $webhook;	
}
?>