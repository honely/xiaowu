<?php

/**
 * list
 * @author auto create
 */
class ProcessInstanceTopVo
{
	
	/** 
	 * 审批实例id
	 **/
	public $process_instance_id;	
}
?>