<?php

/**
 * 角色列表
 * @author auto create
 */
class Roles
{
	
	/** 
	 * 角色ID
	 **/
	public $id;
	
	/** 
	 * 角色名称
	 **/
	public $role_name;	
}
?>