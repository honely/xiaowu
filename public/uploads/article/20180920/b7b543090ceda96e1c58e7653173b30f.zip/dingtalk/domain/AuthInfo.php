<?php

/**
 * auth_info
 * @author auto create
 */
class AuthInfo
{
	
	/** 
	 * agent
	 **/
	public $agent;	
}
?>