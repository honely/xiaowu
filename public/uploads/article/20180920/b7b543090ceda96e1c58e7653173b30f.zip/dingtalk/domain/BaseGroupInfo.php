<?php

/**
 * result
 * @author auto create
 */
class BaseGroupInfo
{
	
	/** 
	 * conversation_id
	 **/
	public $conversation_id;
	
	/** 
	 * icon
	 **/
	public $icon;
	
	/** 
	 * open_conversation_id
	 **/
	public $open_conversation_id;
	
	/** 
	 * owner
	 **/
	public $owner;
	
	/** 
	 * tag
	 **/
	public $tag;
	
	/** 
	 * title
	 **/
	public $title;	
}
?>