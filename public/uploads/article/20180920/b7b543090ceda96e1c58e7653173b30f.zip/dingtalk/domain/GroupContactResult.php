<?php

/**
 * value
 * @author auto create
 */
class GroupContactResult
{
	
	/** 
	 * aliTmpDept
	 **/
	public $ali_tmp_dept;
	
	/** 
	 * flowerName
	 **/
	public $flower_name;
	
	/** 
	 * jobNumber
	 **/
	public $job_number;
	
	/** 
	 * 姓名
	 **/
	public $name;
	
	/** 
	 * 职位
	 **/
	public $title;
	
	/** 
	 * userid
	 **/
	public $userid;
	
	/** 
	 * workStation
	 **/
	public $work_station;	
}
?>