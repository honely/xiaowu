<?php

/**
 * result
 * @author auto create
 */
class GetMessageStatusResponse
{
	
	/** 
	 * 发送失败的详情 receiverId：失败的id code：失败的错误码 msg：失败的原因
	 **/
	public $failed_model;
	
	/** 
	 * 已读的接收者及时间列表 receiverId：用户id readTime：阅读时间，Long
	 **/
	public $read_model;
	
	/** 
	 * 消息任务执行返回码 0表示成功
	 **/
	public $task_code;
	
	/** 
	 * 错误信息
	 **/
	public $task_msg;
	
	/** 
	 * 消息任务执行状态 0：初始化，刚提交时的状态 3：处理中 4：处理完成 5：撤销
	 **/
	public $task_status;	
}
?>