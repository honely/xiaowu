<?php

/**
 * 成本中心对象
 * @author auto create
 */
class OpenCostCenterSaveRs
{
	
	/** 
	 * 商旅横版中心id
	 **/
	public $id;	
}
?>