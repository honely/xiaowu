<?php

/**
 * 请求对象
 * @author auto create
 */
class GetGroupInfoRequest
{
	
	/** 
	 * 群ID
	 **/
	public $chatid;	
}
?>