<?php

/**
 * result
 * @author auto create
 */
class AddMembersResponseModel
{
	
	/** 
	 * dingtalkId
	 **/
	public $dingtalk_id;	
}
?>