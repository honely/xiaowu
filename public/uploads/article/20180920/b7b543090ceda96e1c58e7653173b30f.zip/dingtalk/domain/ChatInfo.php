<?php

/**
 * chat_info
 * @author auto create
 */
class ChatInfo
{
	
	/** 
	 * agentidlist
	 **/
	public $agentidlist;
	
	/** 
	 * conversationTag
	 **/
	public $conversation_tag;
	
	/** 
	 * extidlist
	 **/
	public $extidlist;
	
	/** 
	 * name
	 **/
	public $name;
	
	/** 
	 * owner
	 **/
	public $owner;
	
	/** 
	 * useridlist
	 **/
	public $useridlist;	
}
?>