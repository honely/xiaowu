<?php

/**
 * result
 * @author auto create
 */
class ColumnValListForTopVo
{
	
	/** 
	 * 列信息与列值数据
	 **/
	public $columns;	
}
?>