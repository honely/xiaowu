<?php

/**
 * 列信息与列值数据
 * @author auto create
 */
class ColumnValForTopVo
{
	
	/** 
	 * 列值数据
	 **/
	public $columnvals;
	
	/** 
	 * 列信息
	 **/
	public $columnvo;	
}
?>