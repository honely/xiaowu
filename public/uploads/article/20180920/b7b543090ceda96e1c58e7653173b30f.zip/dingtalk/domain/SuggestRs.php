<?php

/**
 * 结果对象
 * @author auto create
 */
class SuggestRs
{
	
	/** 
	 * 城市列表
	 **/
	public $cities;
	
	/** 
	 * 是否为临近城市
	 **/
	public $nearby;	
}
?>