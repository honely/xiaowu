<?php

/**
 * result
 * @author auto create
 */
class GroupMemberInfo
{
	
	/** 
	 * ext
	 **/
	public $ext;
	
	/** 
	 * id
	 **/
	public $id;
	
	/** 
	 * nick
	 **/
	public $nick;
	
	/** 
	 * role
	 **/
	public $role;
	
	/** 
	 * type
	 **/
	public $type;	
}
?>