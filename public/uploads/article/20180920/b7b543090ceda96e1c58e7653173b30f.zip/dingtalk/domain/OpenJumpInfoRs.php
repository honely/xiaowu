<?php

/**
 * module
 * @author auto create
 */
class OpenJumpInfoRs
{
	
	/** 
	 * 跳转url
	 **/
	public $url;	
}
?>