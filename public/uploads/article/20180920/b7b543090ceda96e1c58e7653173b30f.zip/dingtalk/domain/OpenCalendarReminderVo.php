<?php

/**
 * 事项开始前提醒
 * @author auto create
 */
class OpenCalendarReminderVo
{
	
	/** 
	 * 距开始时多久进行提醒(单位:分钟)
	 **/
	public $minutes;
	
	/** 
	 * 提醒类型:app-应用内;
	 **/
	public $remind_type;	
}
?>