<?php

/**
 * head
 * @author auto create
 */
class Head
{
	
	/** 
	 * bgcolor
	 **/
	public $bgcolor;
	
	/** 
	 * text
	 **/
	public $text;	
}
?>