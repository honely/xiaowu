<?php

/**
 * 创建群请求对象
 * @author auto create
 */
class CreateGroupRequest
{
	
	/** 
	 * hema
	 **/
	public $channel;
	
	/** 
	 * 创建者
	 **/
	public $creater;
	
	/** 
	 * 扩展数据
	 **/
	public $extension;
	
	/** 
	 * 群成员列表
	 **/
	public $member_list;
	
	/** 
	 * 群名称
	 **/
	public $name;
	
	/** 
	 * 群类型
	 **/
	public $type;
	
	/** 
	 * 用于去重
	 **/
	public $uuid;	
}
?>