<?php

/**
 * 表单列表
 * @author auto create
 */
class FormItemVo
{
	
	/** 
	 * 内容
	 **/
	public $content;
	
	/** 
	 * 标题
	 **/
	public $title;	
}
?>