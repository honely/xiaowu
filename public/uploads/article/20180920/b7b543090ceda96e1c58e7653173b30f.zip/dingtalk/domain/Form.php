<?php

/**
 * form
 * @author auto create
 */
class Form
{
	
	/** 
	 * key
	 **/
	public $key;
	
	/** 
	 * value
	 **/
	public $value;	
}
?>