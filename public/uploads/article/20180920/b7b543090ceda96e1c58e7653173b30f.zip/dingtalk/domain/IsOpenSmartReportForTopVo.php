<?php

/**
 * result
 * @author auto create
 */
class IsOpenSmartReportForTopVo
{
	
	/** 
	 * 判断企业是否开启了考勤智能报表，true表示开启
	 **/
	public $smart_report;	
}
?>