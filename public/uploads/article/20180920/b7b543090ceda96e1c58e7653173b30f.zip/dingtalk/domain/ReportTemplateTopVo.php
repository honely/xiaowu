<?php

/**
 * list
 * @author auto create
 */
class ReportTemplateTopVo
{
	
	/** 
	 * 模板图标url
	 **/
	public $icon_url;
	
	/** 
	 * 日志模板名称
	 **/
	public $name;
	
	/** 
	 * 模板唯一标识
	 **/
	public $report_code;
	
	/** 
	 * 模板的url
	 **/
	public $url;	
}
?>