<?php

/**
 * btn_json_list
 * @author auto create
 */
class BtnJsonList
{
	
	/** 
	 * action_url
	 **/
	public $action_url;
	
	/** 
	 * title
	 **/
	public $title;	
}
?>