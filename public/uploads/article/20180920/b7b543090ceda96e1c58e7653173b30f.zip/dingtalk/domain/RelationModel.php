<?php

/**
 * result
 * @author auto create
 */
class RelationModel
{
	
	/** 
	 * beginTime
	 **/
	public $begin_time;
	
	/** 
	 * dstImOpenid
	 **/
	public $dst_im_openid;
	
	/** 
	 * endTime
	 **/
	public $end_time;
	
	/** 
	 * srcImOpenid
	 **/
	public $src_im_openid;	
}
?>