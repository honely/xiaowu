<?php

/**
 * 发送者
 * @author auto create
 */
class AccountInfo
{
	
	/** 
	 * 账号通道
	 **/
	public $channel;
	
	/** 
	 * 账号ID
	 **/
	public $id;
	
	/** 
	 * 账号类型
	 **/
	public $type;	
}
?>