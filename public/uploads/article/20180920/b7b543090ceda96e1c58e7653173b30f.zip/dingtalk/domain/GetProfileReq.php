<?php

/**
 * 获取profile入参
 * @author auto create
 */
class GetProfileReq
{
	
	/** 
	 * 用户信息
	 **/
	public $account_info;	
}
?>