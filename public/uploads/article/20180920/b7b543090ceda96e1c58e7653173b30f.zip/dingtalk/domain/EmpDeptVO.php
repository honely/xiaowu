<?php

/**
 * 离职部门列表
 * @author auto create
 */
class EmpDeptVO
{
	
	/** 
	 * 部门id
	 **/
	public $dept_id;
	
	/** 
	 * 部门路径
	 **/
	public $dept_path;	
}
?>