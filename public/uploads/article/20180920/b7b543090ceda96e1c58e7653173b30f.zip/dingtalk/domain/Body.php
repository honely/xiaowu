<?php

/**
 * body
 * @author auto create
 */
class Body
{
	
	/** 
	 * author
	 **/
	public $author;
	
	/** 
	 * content
	 **/
	public $content;
	
	/** 
	 * file_count
	 **/
	public $file_count;
	
	/** 
	 * form
	 **/
	public $form;
	
	/** 
	 * image
	 **/
	public $image;
	
	/** 
	 * rich
	 **/
	public $rich;
	
	/** 
	 * title
	 **/
	public $title;	
}
?>