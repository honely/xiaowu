<?php

/**
 * 表单详情列表
 * @author auto create
 */
class FormComponentValueVo
{
	
	/** 
	 * 标签扩展值
	 **/
	public $ext_value;
	
	/** 
	 * 标签名
	 **/
	public $name;
	
	/** 
	 * 标签值
	 **/
	public $value;	
}
?>