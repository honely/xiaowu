<?php

/**
 * 此消息类型为固定markdown
 * @author auto create
 */
class Markdown
{
	
	/** 
	 * markdown格式的消息
	 **/
	public $text;
	
	/** 
	 * 首屏会话透出的展示内容
	 **/
	public $title;	
}
?>