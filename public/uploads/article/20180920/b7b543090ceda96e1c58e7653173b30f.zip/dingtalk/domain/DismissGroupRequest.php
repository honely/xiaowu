<?php

/**
 * 解散群请求
 * @author auto create
 */
class DismissGroupRequest
{
	
	/** 
	 * 群ID
	 **/
	public $chatid;	
}
?>