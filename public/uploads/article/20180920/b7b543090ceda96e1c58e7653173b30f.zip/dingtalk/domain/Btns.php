<?php

/**
 * 按钮的信息
 * @author auto create
 */
class Btns
{
	
	/** 
	 * 按钮方案，
	 **/
	public $action_u_r_l;
	
	/** 
	 * 点击按钮触发的URL此消息类型为固定feedCard
	 **/
	public $title;	
}
?>