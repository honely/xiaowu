<?php

/**
 * results
 * @author auto create
 */
class OpenLabelGroup
{
	
	/** 
	 * 标签组颜色
	 **/
	public $color;
	
	/** 
	 * labels
	 **/
	public $labels;
	
	/** 
	 * 标签组名字
	 **/
	public $name;	
}
?>