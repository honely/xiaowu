<?php

/**
 * 休息结束时间
 * @author auto create
 */
class AtTimeVo
{
	
	/** 
	 * 结束时间
	 **/
	public $check_time;
	
	/** 
	 * 类型OnDuty：休息开始，OffDuty：休息结束
	 **/
	public $check_type;	
}
?>