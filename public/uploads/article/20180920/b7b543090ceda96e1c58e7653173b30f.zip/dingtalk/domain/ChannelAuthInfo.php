<?php

/**
 * channel_auth_info
 * @author auto create
 */
class ChannelAuthInfo
{
	
	/** 
	 * channelAgent
	 **/
	public $channel_agent;	
}
?>