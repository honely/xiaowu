<?php

/**
 * 使用独立跳转ActionCard样式时的按钮的链接url
 * @author auto create
 */
class BtnJson
{
	
	/** 
	 * 使用独立跳转ActionCard样式时的按钮的标题
	 **/
	public $action_url;
	
	/** 
	 * 使用独立跳转ActionCard样式时的按钮的链接url
	 **/
	public $title;	
}
?>