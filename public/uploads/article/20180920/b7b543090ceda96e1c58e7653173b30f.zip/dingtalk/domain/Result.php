<?php

/**
 * result
 * @author auto create
 */
class Result
{
	
	/** 
	 * 分页是否还有数据
	 **/
	public $has_more;
	
	/** 
	 * 角色分组列表
	 **/
	public $list;	
}
?>