<?php

/**
 * action_card
 * @author auto create
 */
class ActionCard
{
	
	/** 
	 * btn_json_list
	 **/
	public $btn_json_list;
	
	/** 
	 * btn_orientation
	 **/
	public $btn_orientation;
	
	/** 
	 * markdown
	 **/
	public $markdown;
	
	/** 
	 * single_title
	 **/
	public $single_title;
	
	/** 
	 * single_url
	 **/
	public $single_url;
	
	/** 
	 * title
	 **/
	public $title;	
}
?>