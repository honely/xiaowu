<?php

/**
 * 人员信息列表
 * @author auto create
 */
class OpenOrgEntityDo
{
	
	/** 
	 * 员工/部门/角色id
	 **/
	public $entity_id;
	
	/** 
	 * 人员类型:1员工，2部门，3角色
	 **/
	public $entity_type;	
}
?>