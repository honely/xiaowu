<?php

/**
 * 返回的业务数据
 * @author auto create
 */
class ProcessTopVo
{
	
	/** 
	 * 可见的流程模板唯一标识，最多20条
	 **/
	public $process_code;	
}
?>