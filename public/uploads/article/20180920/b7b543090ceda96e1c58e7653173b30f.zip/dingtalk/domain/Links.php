<?php

/**
 * links
 * @author auto create
 */
class Links
{
	
	/** 
	 * 点击单条信息到跳转链接
	 **/
	public $message_u_r_l;
	
	/** 
	 * 单条信息文本
	 **/
	public $pic_u_r_l;
	
	/** 
	 * 单条信息后面图片的URL
	 **/
	public $title;	
}
?>