<?php

/**
 * oa
 * @author auto create
 */
class OA
{
	
	/** 
	 * body
	 **/
	public $body;
	
	/** 
	 * head
	 **/
	public $head;
	
	/** 
	 * message_url
	 **/
	public $message_url;
	
	/** 
	 * pc_message_url
	 **/
	public $pc_message_url;	
}
?>