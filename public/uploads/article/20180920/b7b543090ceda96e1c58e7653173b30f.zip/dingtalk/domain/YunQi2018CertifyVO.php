<?php

/**
 * result
 * @author auto create
 */
class YunQi2018CertifyVO
{
	
	/** 
	 * 实名时的脸图
	 **/
	public $certify_face_image;
	
	/** 
	 * 是否已实名
	 **/
	public $has_certify;
	
	/** 
	 * 是否需要补录脸
	 **/
	public $need_enter_face;	
}
?>