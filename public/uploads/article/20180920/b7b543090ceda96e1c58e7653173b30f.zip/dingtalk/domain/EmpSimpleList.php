<?php

/**
 * list
 * @author auto create
 */
class EmpSimpleList
{
	
	/** 
	 * userId
	 **/
	public $userid;	
}
?>