<?php

/**
 * 步数列表
 * @author auto create
 */
class BasicStepInfoVo
{
	
	/** 
	 * 统计的时间
	 **/
	public $stat_date;
	
	/** 
	 * 步数
	 **/
	public $step_count;
	
	/** 
	 * 员工userid
	 **/
	public $userid;	
}
?>