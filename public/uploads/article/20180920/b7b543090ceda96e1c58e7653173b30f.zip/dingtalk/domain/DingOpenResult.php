<?php

/**
 * result
 * @author auto create
 */
class DingOpenResult
{
	
	/** 
	 * dingOpenErrcode
	 **/
	public $ding_open_errcode;
	
	/** 
	 * errorMsg
	 **/
	public $error_msg;
	
	/** 
	 * result
	 **/
	public $result;
	
	/** 
	 * success
	 **/
	public $success;	
}
?>