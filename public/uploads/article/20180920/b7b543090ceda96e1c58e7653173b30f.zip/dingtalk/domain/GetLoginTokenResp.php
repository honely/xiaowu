<?php

/**
 * result
 * @author auto create
 */
class GetLoginTokenResp
{
	
	/** 
	 * expire
	 **/
	public $expire;
	
	/** 
	 * loginToken
	 **/
	public $login_token;	
}
?>