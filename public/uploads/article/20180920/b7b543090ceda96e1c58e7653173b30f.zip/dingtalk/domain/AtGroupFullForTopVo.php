<?php

/**
 * result
 * @author auto create
 */
class AtGroupFullForTopVo
{
	
	/** 
	 * 考勤组中的班次列表
	 **/
	public $classes;
	
	/** 
	 * 考勤组id
	 **/
	public $group_id;
	
	/** 
	 * 考勤组名称
	 **/
	public $name;
	
	/** 
	 * 考勤组类型
	 **/
	public $type;	
}
?>