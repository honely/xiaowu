<?php

/**
 * labels
 * @author auto create
 */
class OpenLabel
{
	
	/** 
	 * 标签id
	 **/
	public $id;
	
	/** 
	 * 标签名字
	 **/
	public $name;	
}
?>