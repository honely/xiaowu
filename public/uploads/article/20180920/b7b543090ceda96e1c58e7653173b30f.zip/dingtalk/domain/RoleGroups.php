<?php

/**
 * 角色分组列表
 * @author auto create
 */
class RoleGroups
{
	
	/** 
	 * 角色分组名称
	 **/
	public $group_name;
	
	/** 
	 * 角色列表
	 **/
	public $roles;	
}
?>