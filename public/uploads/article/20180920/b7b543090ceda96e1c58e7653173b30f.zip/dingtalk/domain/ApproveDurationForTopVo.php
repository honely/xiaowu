<?php

/**
 * result
 * @author auto create
 */
class ApproveDurationForTopVo
{
	
	/** 
	 * 请假时长（单位分钟）
	 **/
	public $duration_in_minutes;	
}
?>