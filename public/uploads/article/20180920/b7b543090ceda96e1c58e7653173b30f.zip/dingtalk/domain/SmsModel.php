<?php

/**
 * 短信接受者信息
 * @author auto create
 */
class SmsModel
{
	
	/** 
	 * 品牌名
	 **/
	public $brandname;
	
	/** 
	 * 员工id
	 **/
	public $userid;
	
	/** 
	 * 员工nick
	 **/
	public $username;	
}
?>