<?php

/**
 * 返回结果
 * @author auto create
 */
class EmpFieldInfoVO
{
	
	/** 
	 * 字段信息列表
	 **/
	public $field_list;
	
	/** 
	 * 员工id
	 **/
	public $userid;	
}
?>