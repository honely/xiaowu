<?php

/**
 * list
 * @author auto create
 */
class OpenEmpSimple
{
	
	/** 
	 * 员工姓名
	 **/
	public $name;
	
	/** 
	 * 员工id
	 **/
	public $userid;	
}
?>