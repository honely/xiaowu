<?php

/**
 * corp_info
 * @author auto create
 */
class CorpInfo
{
	
	/** 
	 * 公司名字
	 **/
	public $corp_name;
	
	/** 
	 * 公司corpid
	 **/
	public $corpid;	
}
?>