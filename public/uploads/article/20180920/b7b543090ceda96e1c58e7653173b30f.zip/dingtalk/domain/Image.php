<?php

/**
 * 图片消息
 * @author auto create
 */
class Image
{
	
	/** 
	 * 图片消息
	 **/
	public $media_id;	
}
?>