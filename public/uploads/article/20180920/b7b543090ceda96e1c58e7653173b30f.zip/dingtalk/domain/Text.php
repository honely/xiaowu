<?php

/**
 * text类型
 * @author auto create
 */
class Text
{
	
	/** 
	 * text类型
	 **/
	public $content;	
}
?>